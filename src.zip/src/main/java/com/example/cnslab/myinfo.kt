package com.example.cnslab

data class myinfo(
    var firstName: String? = null)