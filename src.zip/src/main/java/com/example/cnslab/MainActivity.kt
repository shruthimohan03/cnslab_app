package com.example.cnslab

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
// import com.example.cnsapp_shruthi.R
import com.example.cnslab.R

class MainActivity : AppCompatActivity() {

    // Initializing the variables globally for the functions to access
    private lateinit var inputUsername: EditText
    private lateinit var inputPassword: EditText
    private lateinit var loginButton: Button
    private var passwordMinLength: Int = 8
    private var passwordUppercase: Boolean = true
    private var passwordLowercase: Boolean = true
    private var passwordDigit: Boolean = true
    private var passwordSpecialChar: Boolean = true


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Getting the inputs from the user
        inputUsername = findViewById(R.id.textInputEditText)
        inputPassword = findViewById(R.id.textInputEditText2)
        loginButton = findViewById(R.id.button)

        // Initially disabling the button because username and password is non-empty
        loginButton.isEnabled = false

        // Using textWatcher to update the login button state dynamically
        inputUsername.addTextChangedListener(textWatcher)
        inputPassword.addTextChangedListener(textWatcher)

        // Checking the credentials
        loginButton.setOnClickListener {
            authenticateUser()
        }
    }


    // To enable the login button only after specific conditions satisfy
    private val textWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            // Initialization is necessary because it is an abstract class
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            // Enable the login button only when both username and password are non-empty
            loginButton.isEnabled =
                inputUsername.text.toString().isNotEmpty() && inputPassword.text.toString()
                    .isNotEmpty()
        }

        override fun afterTextChanged(s: Editable?) {
            // Initialization is necessary because it is an abstract class
        }
    }

    // Checking to allow the user to login successfully
    private fun authenticateUser() {
        // Hardcoded username and password as credentials(cred)
        val cred = arrayOf(
            Pair("username", "Password@123"),
            Pair("cnslab", "pass_CNSlab456"),
            Pair("iitm", "iit_madras789")
        )

        // Checking the credentials
        val errorUsername: TextView = findViewById(R.id.textView2)
        val errorPassword: TextView = findViewById(R.id.textView3)
        if (usernameCheck(inputUsername.text.toString()) && passwordCheck(inputPassword.text.toString())) {
            val validUser =
                cred.any { it.first == inputUsername.text.toString() && it.second == inputPassword.text.toString() }

            var confirmationMessage: String
            if (validUser){
                confirmationMessage="Login Successful!"
                navigateToHomeScreen()
            }else{
                confirmationMessage="Login Unsuccessful, credentials do not match"
            }
            val confirmation = Toast.makeText(this, confirmationMessage, Toast.LENGTH_LONG)
            confirmation.show()
        } else {
            // Display error messages for invalid username or password
            if (!usernameCheck(inputUsername.text.toString())) {
                errorUsername.setText("Invalid username: \n"+"Minimum length=4 \n" + "Should not contain space")
            }
            if (!passwordCheck(inputPassword.text.toString())) {
                errorPassword.setText("Invalid password:\n"+"Minimum length=8 \n" +
                        "Should contain alphanumeric, uppercase and special characters\n"+"Should not contain space")
            }
        }

        // Clearing the text fields after the login button is clicked
        inputUsername.text.clear()
        inputPassword.text.clear()
    }

    // Conditions to satisfy for username
    private fun usernameCheck(username: String): Boolean {

        // Minimum username length should be 4 and should not contain spaces
        return username.length >= 4 && !username.contains(" ")
    }

    // Conditions to satisfy for password
    private fun passwordCheck(password: String): Boolean {
        passwordMinLength = 8
        passwordUppercase = password.any { it.isUpperCase() }
        passwordLowercase = password.any { it.isLowerCase() }
        passwordDigit = password.any { it.isDigit() }
        passwordSpecialChar = password.any { !it.isLetterOrDigit() }

        // Password should have minimum 8 characters and must contain all types of characters
        return password.length >= passwordMinLength && passwordUppercase && passwordLowercase && passwordDigit && passwordSpecialChar
    }


    // To provide a detailed error message based on the failed conditions
    private fun getPasswordErrorMessage(): String {
        val requirements = mutableListOf<String>()

        if (passwordMinLength > 0) {
            requirements.add("at least $passwordMinLength characters")
        }
        if (passwordUppercase) {
            requirements.add("at least one uppercase letter")
        }
        if (passwordLowercase) {
            requirements.add("at least one lowercase letter")
        }
        if (passwordDigit) {
            requirements.add("at least one digit")
        }
        if (passwordSpecialChar) {
            requirements.add("at least one special character")
        }

        return "Password must contain ${requirements.joinToString(", and ")}"
    }

    private fun navigateToHomeScreen() {
        // Create an Intent to start the new activity
        val intent = Intent(this, HomeScreen::class.java)
        startActivity(intent)

        // Finish the current activity to prevent going back to the login screen
        finish()
    }
}