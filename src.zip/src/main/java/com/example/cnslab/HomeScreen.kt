package com.example.cnslab

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.cnslab.R
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class HomeScreen : AppCompatActivity() {

    private var i: Int =0
    private lateinit var firstName: EditText
    private lateinit var lastName: EditText
    private lateinit var email: EditText
    private lateinit var buttonSubmit: Button

    private lateinit var database: FirebaseDatabase
    private lateinit var myRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)

        /* Initialize Firebase */
        try{
        database = FirebaseDatabase.getInstance()
            //val database = Firebase.database
        myRef = database.getReference("mydb")}
        catch(e: Exception){
            print(e.message)
        }

        // getting the object of the input texts
        firstName = findViewById(R.id.editText1)
        lastName = findViewById(R.id.editText2)
        email = findViewById(R.id.editemailText)
        buttonSubmit = findViewById(R.id.button7)

        buttonSubmit.setOnClickListener {
            // Get user input
            val userFirstName = firstName.text.toString()
            val userLastName = lastName.text.toString()
            val userEmail = email.text.toString()
            //lastName.setText(userFirstName)

            // Backend communication
            val infoClass=myinfo(userFirstName)
            try{
                myRef.setValue(infoClass)
                var message: TextView =findViewById(R.id.textView5)
                message.setText("Thank you! \n The details are successfully stored in the database")
            }
            catch(e:Exception){
                var message: TextView =findViewById(com.example.cnslab.R.id.textView5)
                message.setText("The details are not successfully stored in the database")
            }
            //lastName.setText(((myinfo)myRef.child("1")).firstName)

            //clear the inputs
            firstName.text.clear()
            lastName.text.clear()
            email.text.clear()
            }
        }
    }

